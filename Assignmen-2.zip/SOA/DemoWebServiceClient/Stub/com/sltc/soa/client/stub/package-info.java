@javax.xml.bind.annotation.XmlSchema(namespace = "http://soa.sltc.com/")
package com.sltc.soa.client.stub;
