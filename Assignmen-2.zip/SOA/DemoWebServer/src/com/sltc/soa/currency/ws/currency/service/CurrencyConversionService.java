package com.sltc.soa.currency.ws.currency.service;

import com.sun.javafx.collections.MappingChange;
import java.util.*;

public class CurrencyConversionService {

    private static Map<String, Double> rates = new HashMap<>();

    private static final String baseCurrency = "USD";

    static {
        init();
    }

    private static void init() {
        rates.put("AED",  3.6732);
        rates.put("SGD",  1.33976);
        rates.put("USD", 1.0);
        rates.put("BHD", 0.377047);
        rates.put("ILS", 3.305165);
        rates.put("IMP", 0.749906);
        rates.put("NIO", 34.853771);
        rates.put("NOK", 8.8847);
        rates.put("NZD", 1.424685);
        rates.put("PHP", 48.109536);
        rates.put("QAR", 3.64075);
        rates.put("ZMW", 21.003963);
        rates.put("ZWL", 322.0);
    }

    public double convert( double amountInSourceCurrency, String sourceCurrency, String targetCurrency){
        double targetCurrencyRate = rates.get(targetCurrency);
        double sourceCurrencyRate = rates.get(sourceCurrency);

        return (amountInSourceCurrency * targetCurrencyRate) / sourceCurrencyRate;
    }
}
