package com.sltc.soa;

import com.sltc.soa.currency.ws.currency.service.CurrencyConversionService;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.Endpoint;

@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class DemoWS
{

    @WebMethod
    public double convert( double amountInSourceCurrency, String sourceCurrency, String targetCurrency){
        CurrencyConversionService service = new CurrencyConversionService();
        return service.convert(amountInSourceCurrency, sourceCurrency, targetCurrency);
    }

    public static void main(String[] args){
        Endpoint.publish("http://localhost:8888/CurrencyConversionService", new DemoWS());
    }
}
